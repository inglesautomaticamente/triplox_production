bool get isMacOs => throw UnimplementedError('Unsupported');
String getUserAgent() => '';
