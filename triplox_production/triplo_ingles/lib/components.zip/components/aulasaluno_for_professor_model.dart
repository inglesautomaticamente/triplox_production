import '/flutter_flow/flutter_flow_util.dart';
import 'aulasaluno_for_professor_widget.dart' show AulasalunoForProfessorWidget;
import 'package:flutter/material.dart';

class AulasalunoForProfessorModel
    extends FlutterFlowModel<AulasalunoForProfessorWidget> {
  ///  State fields for stateful widgets in this component.

  final aulasalunoForProfessorShortcutsFocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    aulasalunoForProfessorShortcutsFocusNode.dispose();
  }
}
