import '/flutter_flow/flutter_flow_util.dart';
import 'cadastro_professor_o_k_widget.dart' show CadastroProfessorOKWidget;
import 'package:flutter/material.dart';

class CadastroProfessorOKModel
    extends FlutterFlowModel<CadastroProfessorOKWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
