import '/flutter_flow/flutter_flow_util.dart';
import 'vazio_aula_widget.dart' show VazioAulaWidget;
import 'package:flutter/material.dart';

class VazioAulaModel extends FlutterFlowModel<VazioAulaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
