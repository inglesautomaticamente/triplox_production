import '/flutter_flow/flutter_flow_util.dart';
import 'teste_cadastrado_widget.dart' show TesteCadastradoWidget;
import 'package:flutter/material.dart';

class TesteCadastradoModel extends FlutterFlowModel<TesteCadastradoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
