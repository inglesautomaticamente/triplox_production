import '/flutter_flow/flutter_flow_util.dart';
import 'nenhuma_nova_aula_widget.dart' show NenhumaNovaAulaWidget;
import 'package:flutter/material.dart';

class NenhumaNovaAulaModel extends FlutterFlowModel<NenhumaNovaAulaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
