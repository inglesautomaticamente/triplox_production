import '/flutter_flow/flutter_flow_util.dart';
import 'historico_saldo_widget.dart' show HistoricoSaldoWidget;
import 'package:flutter/material.dart';

class HistoricoSaldoModel extends FlutterFlowModel<HistoricoSaldoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
