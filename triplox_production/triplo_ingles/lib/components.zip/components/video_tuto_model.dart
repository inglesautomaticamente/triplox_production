import '/flutter_flow/flutter_flow_util.dart';
import 'video_tuto_widget.dart' show VideoTutoWidget;
import 'package:flutter/material.dart';

class VideoTutoModel extends FlutterFlowModel<VideoTutoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
