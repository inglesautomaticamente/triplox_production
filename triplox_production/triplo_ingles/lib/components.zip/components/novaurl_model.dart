import '/flutter_flow/flutter_flow_util.dart';
import 'novaurl_widget.dart' show NovaurlWidget;
import 'package:flutter/material.dart';

class NovaurlModel extends FlutterFlowModel<NovaurlWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
