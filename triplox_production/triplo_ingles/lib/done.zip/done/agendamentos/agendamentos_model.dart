import '/flutter_flow/flutter_flow_util.dart';
import 'agendamentos_widget.dart' show AgendamentosWidget;
import 'package:flutter/material.dart';

class AgendamentosModel extends FlutterFlowModel<AgendamentosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
